<?php
// config/database.php
class Database {
    private static $instance = null;
    private $pdo;
    
    private function __construct() {
        try {
            // Usar SQLite por defecto
            $dbFile = __DIR__ . '/../database.sqlite';
            $this->pdo = new PDO("sqlite:$dbFile");
            $this->pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            $this->createTables();
        } catch (PDOException $e) {
            die("Error de conexión: " . $e->getMessage());
        }
    }
    
    public static function getInstance() {
        if (self::$instance === null) {
            self::$instance = new Database();
        }
        return self::$instance;
    }
    
    public function getConnection() {
        return $this->pdo;
    }
    
    private function createTables() {
        // Tabla de usuarios
        $this->pdo->exec("
            CREATE TABLE IF NOT EXISTS usuarios (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                username TEXT UNIQUE NOT NULL,
                password TEXT NOT NULL,
                email TEXT UNIQUE NOT NULL,
                rol TEXT DEFAULT 'vendedor',
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP
            )
        ");
        
        // Tabla de productos
        $this->pdo->exec("
            CREATE TABLE IF NOT EXISTS productos (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                nombre TEXT NOT NULL,
                descripcion TEXT,
                precio_bs REAL NOT NULL,
                precio_usd REAL NOT NULL,
                stock INTEGER DEFAULT 0,
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP
            )
        ");
        
        // Tabla de ventas
        $this->pdo->exec("
            CREATE TABLE IF NOT EXISTS ventas (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                usuario_id INTEGER,
                total_bs REAL,
                total_usd REAL,
                moneda TEXT,
                tasa_cambio REAL,
                fecha DATETIME DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (usuario_id) REFERENCES usuarios(id)
            )
        ");
        
        // Tabla de detalles de venta
        $this->pdo->exec("
            CREATE TABLE IF NOT EXISTS ventas_detalles (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                venta_id INTEGER,
                producto_id INTEGER,
                cantidad INTEGER,
                precio_bs REAL,
                precio_usd REAL,
                subtotal_bs REAL,
                subtotal_usd REAL,
                FOREIGN KEY (venta_id) REFERENCES ventas(id),
                FOREIGN KEY (producto_id) REFERENCES productos(id)
            )
        ");
        
        // Insertar usuario admin por defecto
        $stmt = $this->pdo->prepare("SELECT COUNT(*) FROM usuarios WHERE username = ?");
        $stmt->execute(['admin']);
        if ($stmt->fetchColumn() == 0) {
            $hashedPassword = password_hash('admin123', PASSWORD_DEFAULT);
            $stmt = $this->pdo->prepare("INSERT INTO usuarios (username, password, email, rol) VALUES (?, ?, ?, ?)");
            $stmt->execute(['admin', $hashedPassword, 'admin@sistema.com', 'admin']);
        }
    }
}
?>