<?php
// includes/functions.php
session_start();

function isLoggedIn() {
    return isset($_SESSION['user_id']);
}

function isAdmin() {
    return isset($_SESSION['rol']) && $_SESSION['rol'] === 'admin';
}

function redirect($url) {
    header("Location: $url");
    exit();
}

function getTasaCambio() {
    // En producción, aquí se puede llamar a una API real del BCV
    // Simulamos tasa de cambio para el ejemplo
    return 40.50; // Tasa de cambio actualizada
}

function formatMoney($amount, $currency = 'Bs') {
    if ($currency === 'USD') {
        return '$ ' . number_format($amount, 2, ',', '.');
    }
    return 'Bs ' . number_format($amount, 2, ',', '.');
}

function generarToken() {
    return bin2hex(random_bytes(32));
}

function verificarToken($token) {
    return isset($_SESSION['csrf_token']) && hash_equals($_SESSION['csrf_token'], $token);
}

// Obtener configuración del comercio (SOLO UNA VEZ)
function getSettings() {
    $db = Database::getInstance()->getConnection();
    $stmt = $db->query("SELECT * FROM settings WHERE id = 1");
    $settings = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$settings) {
        // Crear configuración por defecto si no existe
        $stmt = $db->prepare("INSERT INTO settings (nombre_comercio, rif, direccion, iva) VALUES (?, ?, ?, ?)");
        $stmt->execute(['Mi Comercio', 'J-12345678-0', 'Dirección del comercio', 16]);
        $stmt = $db->query("SELECT * FROM settings WHERE id = 1");
        $settings = $stmt->fetch(PDO::FETCH_ASSOC);
    }
    return $settings;
}

// Obtener tasa de cambio con caché
function getExchangeRate() {
    $cache_file = __DIR__ . '/../cache/dolar_rate.json';
    $cache_time = 300; // 5 minutos
    
    // Crear directorio cache si no existe
    if (!file_exists(__DIR__ . '/../cache')) {
        mkdir(__DIR__ . '/../cache', 0777, true);
    }
    
    if (file_exists($cache_file) && (time() - filemtime($cache_file)) < $cache_time) {
        $data = json_decode(file_get_contents($cache_file), true);
        return $data['rate'] ?? null;
    }
    
    // Verificar si cURL está disponible
    if (!function_exists('curl_init')) {
        return null;
    }
    
    $url = 'https://ve.dolarapi.com/v1/dolares/oficial';
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    curl_setopt($ch, CURLOPT_TIMEOUT, 10);
    curl_setopt($ch, CURLOPT_HTTPHEADER, ['User-Agent: SistemaVentas/1.0']);
    $response = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    
    if ($httpCode === 200 && $response) {
        $data = json_decode($response, true);
        if (isset($data['promedio'])) {
            file_put_contents($cache_file, json_encode(['rate' => $data['promedio']]));
            return $data['promedio'];
        }
    }
    return null;
}
?>